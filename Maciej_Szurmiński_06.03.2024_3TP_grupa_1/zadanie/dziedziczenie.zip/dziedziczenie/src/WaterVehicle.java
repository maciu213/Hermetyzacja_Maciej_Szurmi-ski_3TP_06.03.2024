public class WaterVehicle extends Vehicle{
    public String ship;

    public WaterVehicle(String model, String brand, double speed, String ship) {
        super(model, brand, speed);
        this.ship = ship;
    }

    public void water(){
        System.out.println("Płynie po oceanie");
    }
}
