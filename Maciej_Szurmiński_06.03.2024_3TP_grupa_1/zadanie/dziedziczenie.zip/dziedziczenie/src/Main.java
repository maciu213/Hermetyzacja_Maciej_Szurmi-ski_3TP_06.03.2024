public class Main {
    public static void main(String[] args) {
        LandVehicle vehicle1 = new LandVehicle("RS6", "Audi", 150.00, "1");
        LandVehicle vehicle2 = new LandVehicle("RS4", "Audi", 200.00, "2");

        AirVehicle vehicle3 = new AirVehicle("Boeing 737", "Boeing", 1000.00, "LOT");
        AirVehicle vehicle4 = new AirVehicle("Boeing 731", "Boeing 2", 1001.00, "LOT2");

        WaterVehicle vehicle5 = new WaterVehicle("Ancient", "Ship", 150.00, "Big");
        WaterVehicle vehicle6 = new WaterVehicle("New", "Ship2", 149.00, "Big2");
        vehicle1.method();
        vehicle2.method();
        vehicle3.method();
        vehicle4.method();
        vehicle5.method();
        vehicle6.method();
    }


}