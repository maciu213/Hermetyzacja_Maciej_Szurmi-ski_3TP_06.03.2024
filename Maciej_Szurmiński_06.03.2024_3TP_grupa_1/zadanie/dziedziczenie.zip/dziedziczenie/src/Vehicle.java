public class Vehicle {
    public String model;
    public String brand;
    public double speed;

    public Vehicle(String model, String brand, double speed) {
        this.model = model;
        this.brand = brand;
        this.speed = speed;
    }


    public String getModel() {
        return model;
    }

    public String getBrand() {
        return brand;
    }

    public double getSpeed() {
        return speed;
    }

    public void method(){
        System.out.println(getModel());
    }
}
