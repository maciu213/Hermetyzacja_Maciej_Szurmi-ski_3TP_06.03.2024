public class AirVehicle extends Vehicle {
    public String name;

    public AirVehicle(String model, String brand, double speed, String name) {
        super(model, brand, speed);
        this.name = name;
    }

    public void air(){
        System.out.println("Lata po niebie");
    }
}
