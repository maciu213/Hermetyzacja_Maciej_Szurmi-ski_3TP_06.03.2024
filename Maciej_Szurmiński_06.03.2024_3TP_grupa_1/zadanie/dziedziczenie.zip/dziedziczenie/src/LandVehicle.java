public class LandVehicle extends Vehicle{
    public String drive;

    public LandVehicle(String model, String brand, double speed, String drive1) {
        super(model, brand, speed);
        this.drive = drive1;
    }

    public void land(){
        System.out.println("Jedzie po drodze");
    }

}
